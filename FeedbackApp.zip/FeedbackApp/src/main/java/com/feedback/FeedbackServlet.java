package com.feedback;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class FeedbackServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String gender = request.getParameter("gender");
        String rating = request.getParameter("rating");
        String experience = request.getParameter("experience");
        String message = request.getParameter("message");
        String suggestions = request.getParameter("suggestions");

        // Store data in request
        request.setAttribute("name", name);
        request.setAttribute("email", email);
        request.setAttribute("phone", phone);
        request.setAttribute("gender", gender);
        request.setAttribute("rating", rating);
        request.setAttribute("experience", experience);
        request.setAttribute("message", message);
        request.setAttribute("suggestions", suggestions);

        RequestDispatcher rd = request.getRequestDispatcher("/feedback.jsp");
        rd.forward(request, response);

    }
}
